// awesome C code 
